" Vim color scheme
"
" Name:         mac_classic.vim
" Maintainer:   Drew Neil <andrew.jr.neil@gmail.com>
" License:      public domain
" Version:      0.1

" Boilerplate: {{{1
set background=light
highlight clear

if exists("syntax_on")
  syntax reset
endif

let g:colors_name = "warren_code"


" GUI: {{{1
hi Cursor  guifg=#FFFFFF ctermfg=15 guibg=#3C4C72 ctermbg=240
hi Visual  guibg=#C6DEFF ctermbg=189
hi CursorLine  guibg=#F0F6FF ctermbg=15
hi CursorColumn  guibg=#F0F6FF ctermbg=15
hi LineNr  guifg=#808080 ctermfg=244 guibg=#EFEFEF ctermbg=7
hi VertSplit  guifg=#FFFFFF ctermfg=15 guibg=#CFCFCF ctermbg=252 gui=NONE
hi MatchParen  guifg=#1E39F6 ctermfg=27 guibg=NONE gui=bold
hi Pmenu guibg=#EFEFEF ctermbg=7
hi PmenuSel  guibg=#C6DEFF ctermbg=189
hi Directory  guifg=#D51015 ctermfg=160 gui=bold
hi Folded  guifg=#0066FF ctermfg=27 guibg=#FFFFFF ctermbg=15
" StatusLine: {{{2
hi StatusLine  guifg=#000000 ctermfg=0 guibg=#EFEFEF ctermbg=7 gui=bolditalic
hi StatusLineNC  guifg=#000000 ctermfg=0 guibg=#EFEFEF ctermbg=7 gui=NONE

" Search: {{{2
" [IncSearch is stronger than Search]
hi IncSearch  guifg=NONE guibg=#FFCE77 ctermbg=222 gui=NONE
hi Search  guibg=#FFE6BB ctermbg=223

" Syntax: {{{1
hi Normal  guifg=#000000 ctermfg=0 guibg=#FFFFFF ctermbg=15
hi Comment guifg=#FF0000 ctermfg=9 gui=italic
hi SpecialComment guifg=#804000 ctermfg=94 gui=italic
hi Constant guifg=#26474B ctermfg=237
hi String guifg=#666666 ctermfg=241
hi Character guifg=#666666 ctermfg=241
hi Number guifg=#1C00CF ctermfg=20
hi Regexp guifg=#666666 ctermfg=241
hi link Boolean Constant
hi link Float Number
hi Identifier guifg=#3F6E74 ctermfg=60
hi Function guifg=#26474B ctermfg=237
hi Statement guifg=#0000FF ctermfg=12
hi link Conditional Keyword
hi link Repeat Keyword
hi link Label Keyword 
hi Operator guifg=#000000 ctermfg=0
hi link Keyword Statement
hi link Exception Statement
hi link cStatement Statement
hi PreProc guifg=#408000 ctermfg=64
hi Macro guifg=#643820 ctermfg=237
hi Type guifg=#3F6E74 ctermfg=60
hi StorageClass guifg=#0F68A0 ctermfg=25
hi Structure guifg=#3F6E74 ctermfg=60
hi Typedef guifg=#0B4F79 ctermfg=24
hi Special guifg=#AA0D91 ctermfg=126


" Invisible character colors
hi NonText  guifg=#DFDFDF ctermfg=253 guibg=#FFFFFF ctermbg=15
hi SpecialKey  guifg=#DFDFDF ctermfg=253 guibg=#FFFFFF ctermbg=15

" Diff styles {{{1
hi diffAdded guifg=#007B22 guibg=#FFFFFF ctermfg=28 ctermbg=15
hi diffRemoved guifg=#D51015 guibg=#FFFFFF ctermfg=160 ctermbg=15
hi diffFile guifg=#6E79F1 guibg=#FFFFFF ctermfg=69 ctermbg=15
hi diffNewFile guifg=#6E79F1 guibg=#FFFFFF ctermfg=69 ctermbg=15
hi diffLine guifg=#000000 guibg=#FFFFFF ctermfg=0 ctermbg=15

hi diffAdd guifg=#007B22 guibg=#FFFFFF ctermfg=28 ctermbg=15
hi diffChange guifg=#007B22 guibg=#FFFFFF ctermfg=28 ctermbg=15
hi diffText guifg=#007B22 guibg=#FFFFFF ctermfg=28 ctermbg=15
hi link diffDelete diffRemoved

" Git styles {{{1
hi gitcommitFirstLine guifg=#000000 guibg=#FFFFFF ctermfg=0 ctermbg=15
hi gitcommitSelectedType guifg=#007B22 guibg=#FFFFFF ctermfg=28 ctermbg=15
hi link gitcommitSelectedFile gitcommitSelectedType
hi gitcommitDiscardedType guifg=#D51015 guibg=#FFFFFF ctermfg=160 ctermbg=15
hi link gitcommitDiscardedFile gitcommitDiscardedType
hi gitcommitUntrackedFile guifg=#6E79F1 guibg=#FFFFFF ctermfg=69 ctermbg=15


" Markdown: {{{1
hi markdownBold gui=bold
hi markdownItalic gui=italic
hi markdownCode  guifg=#007B22 ctermfg=28
hi link markdownCodeBlock markdownCode

" Outliner: {{{1
hi BT1 guifg=#808080 ctermfg=244 gui=italic
hi OL1 guifg=#000000 ctermfg=0 gui=bold
hi OL2 guifg=#0000A2 ctermfg=19 gui=bold
hi OL3 guifg=#007B22 ctermfg=28 gui=bold
hi OL4 guifg=#6E79F1 ctermfg=69 gui=NONE
" Modelines: {{{1
" vim: nowrap fdm=marker
" }}}
